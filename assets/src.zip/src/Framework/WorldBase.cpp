#include "pvz/Framework/WorldBase.hpp"
#include "pvz/Framework/GameManager.hpp"

WorldBase::WorldBase() {}

WorldBase::~WorldBase() {}
